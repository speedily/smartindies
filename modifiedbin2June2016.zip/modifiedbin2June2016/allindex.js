var jsonList ={
    "Table": [
        {
            "stateid": "01-June-2015",
            "release": "past",
            "html": "",
            "source": "https://i1.ytimg.com/vi/JqZsWrgO73I/0.jpg",
            "alt": "Smart Indies FAQs"
        },
        {
            "stateid":"15-August-2015",
            "release": "past",
            "html": "",
            "source": "./images/ebooks/15-08-2015.jpg",
            "alt": "Smart Indies"
        },
        {
            "stateid":"15-September-2015",
            "release": "past",
            "html": "",
            "source": "./images/ebooks/15-09-2015.jpg",
            "alt": "Smart Indies"
        },
        {
            "stateid":"15-November-2015",
            "release": "past",
            "html": "",
            "source": "./images/ebooks/15-11-2015.jpg",
            "alt": "Smart Indies"
        },
        {
            "stateid":"15-February-2016",
            "release": "current",
            "html": "",
            "source": "./images/ebooks/15-02-2016.jpg",
            "alt": "Smart Indies"
        }

    ]
}

//this is better than json as it is always included as a js variable -  html 2 js converted
/* text link
<br/>yahoo <a href="http://www.yahoo.com"></a>
"<br/>yahoo <a href=\"http://www.yahoo.com\"></a>";
*/
/* the image tag
<img src="//placehold.it/300x300" class="img-responsive  center-block">
" <img src=\"//placehold.it/300x300\" class=\"img-responsive  center-block\"> ";

*/
/* the videotag
<iframe width="560" height="315" src="https://www.youtube.com/embed/JqZsWrgO73I?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen class="center-block"></iframe>

    <div class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/JqZsWrgO73I?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
</div>

" <div class=\"embed-responsive embed-responsive-16by9\">
   <iframe class=\"embed-responsive-item\" src=\"https://www.youtube.com/embed/JqZsWrgO73I?rel=0&amp;showinfo=0\" frameborder=\"0\" allowfullscreen></iframe>
 </div> ";
*/
